<header class='fixed-top'>

  <nav class="navbar navbar-expand-sm navbar-dark bg-dark p-2">

    <a class="navbar-brand" href="index.php">TM Project</a>

    <div id="navbarNav">

      <ul class="navbar-nav">

        <li class="nav-item">
          <a class="nav-link" href="movies.php">Filmes</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="foods.php">Comidas</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="games.php">Jogos</a>
        </li>

      </ul>

    </div>

  </nav>

</header>