<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title> Curso PHP FUNDAMENTAL</title>
	</head>

	<body>
        <center>
		<p>
			
			<form name="exe1" action="validador_cpf1.php" method ="post">
			
			
			 <label>
			     <a> Insira seu CPF: </a>
			 </label>	
            <input name="cpf" type="text" >
			<br>
            <br>
                
                
            <input type="submit" name="text">

			</form>

		
		
		</center>
		
	</body>

</html>