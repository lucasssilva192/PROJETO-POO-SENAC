<html lang="pt-br">
    <head>
        <meta http-equiv="Content Type" content="text/hmtl" charset="UTF-8">
        <link href="../CSS/estilos.css" type="text/css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
        <title> SiCadPF </title>
    </head>
    
    <body>
        <div id="background"> 
              <center>
                <img src="logo.png" id="logo" width="200"/>
                    <div id="bloco_branco">
                        <p> Selecione uma das opções abaixo. </p>
                            <br>
                                <a href="inserir_banco.php"> 
                                    <button name="Cadastrar" class="botao_bloco" id="botao">
                                        <p>Cadastrar</p>
                                    </button>
                                </a>
                            <br>
                            <br>
                               <a href="listar_banco.php">
                                    <button name="Listar" class="botao_bloco" id="botao">
                                        <p> Listar </p>
                               </button>
                            <br>
                            <br>
                                <a href="alterar_banco.php">
                                    <button name="Editar" class="botao_bloco" id="botao">
                                        <p> Editar </p>
                                    </button>
                                </a>
                    </div>
                </center>
        </div>
    </body>
</html>     