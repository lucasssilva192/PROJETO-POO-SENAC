<?php

interface iMovie {

  public function setData(array $data):bool;
  public function getData():array;
  
}