<?php

//Informações para conectar no banco
define( 'DSN', 'mysql:dbname=netunopi;host=localhost'); //driver, nome banco, server
define( 'DBUSER', 'root'); //usuário
define( 'DBPASS', ''); // senha