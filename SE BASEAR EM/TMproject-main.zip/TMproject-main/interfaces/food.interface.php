<?php

interface iFood {

  public function setData(array $data):bool;
  public function getData():array;
  
}