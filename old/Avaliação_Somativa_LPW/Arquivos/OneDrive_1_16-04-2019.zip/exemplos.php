<?php 
	$nome = "Lucas";
	$sobrenome = "Santos Silva a a a a ";
	$nome_completo = $nome ." ". $sobrenome; 
	$salario = 1500;
	$nomes = array ("ana", "beto", "vivan", "luan");
	$nomes_2 = array (10, "Carter", array (20,"Jonas",30));
	$a = 1;
	$b = 8;
	$dia = "1";
	$fumante = true;
	define ("MESES", 12);



?>

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title> Curso PHP FUNDAMENTAL</title>
	</head>

	<body>
		<p> <?php // echo "aaa"; ?> </p>
		<p> <?php //echo "Brasil"; ?> </p> 
		<p> <?php // sem aspas faz conta e tals
		//echo 40*2; ?> </p>
		<!-- fácil nao -->
		<center> 
		<p> <?php //echo  "OoOoOoO"; ?> </p> 
		<p> <?php //echo $nome; ?> </p>
		<p> <?php// echo $salario; ?> </p> 
		<p> <?php //echo $salario*2; ?> </p> 
		<p> <?php// echo "Sr. " . $nome_completo . " Seu salário é: " . $salario ; ?> </p>
		<p> <?php //echo strlen ($nome) . "</br>" ?> </p>
		<p> <?php// echo stripos ($nome, "u"); ?> </p>
		<p> <?php// echo strripos ($nome,"u"); ?> </p>
		<p> <?php// echo strtolower ($nome) . "</br>" ?> </p>
		<p> <?php// echo strtoupper ($nome) . "</br>" ?> </p>
		<p> <?php //echo SUBSTR_COUNT ($nome, "c") . "</br>" ?> </p>
		<p> <?php// echo "randomico ". rand(1,10000) . "</br>" ?> </p>
		<p> <?php// echo "Sr. " . $nomes[3]; ?> </p>
		<p> <?php// echo $nomes[1]; ?> </p>
		<p> <?php// echo $nomes_2[0]; ?> </p>
		<p> <?php 
		
						//		$sorteio = array(0);
				//$contador=0;


				//while ($contador <10)
				//{
					//$sorteio[$contador] = rand(1,100);
					//$contador++;
				//}
				
				//sort($sorteio);
				//$contador=0;
				
				
				//while ($contador <10)
				//{
				//	echo $sorteio[$contador] . "," . "<br>";
				//	$contador ++;
				//}
				
				//echo "-----------------" . "<br>";
				
				//for ($contador = 1; $contador<=6; $contador++)
				//{
				//	echo rand(1,100) . "<br>";
				//}
				
				 // echo count($nomes) . "<br>";
				 // echo count($nomes) . " é a quantidade de nomes e eles são " . $nomes[0] . "," . $nomes[1] . "," . $nomes[2] . "," . $nomes[3] . "." . "<br>";
				//  echo "quantidade de meses no ano é " . MESES . "<br>";
				//  echo "3 anos equivalem a " . MESES*3 . " meses" . "<br>";
				  
				//  if ($a > $b )
				//  {
				//	echo $a . " é maior que " . $b . "<br>";
				//  }
				  
				//  else
				//  {
				//	echo $b . " é maior que " . $a . "<br>";
				//  }
				  

				//  if ($fumante = true || $fumante = false)
				//  {
				//	 echo "fumantes não são bem vindos.". "<br>";
				//  }
				//   else
				//  {
			//		 echo "ainda bem pois fumantes não são bem vindos.". "<br>";
			//	  }
				  

				//switch ($dia)
				//{
			//	case "segunda":
		//		echo "hoje não é segunda";
		//		break;

		//		case "sexta":
		//		echo "hoje é sexta";
		//		break;
//
	//			default:
		//		echo "são apenas aceitos dias da semana". "<br>";
			//	}
							//$salarioo = 800;
			//	$premio = "800";
			//	if ($salarioo === $premio)
			//	{
			//		echo "o salário é igual o premio" . "<br>";
			//	}
			//	else 
			//	{
			//		echo "o salário não é igual o premio" . "<br>";
			//	}
				
				
			/*echo "EXERCICIO 1" . "<br>"; 
			
			$numero1 = 11;
			$numero2 = 10;
			$result = $numero1 + $numero2;
			if ($result > 20)
			{
			echo "$result". "<br>";
			}

			$result + 8;
			
			if ($result >= 20)
			{
				$result = $result-5;
				echo "$result" . "<br>";
			}
			echo "_________________________" . "<br>";
			
			echo "EXERCICIO 2" . "<br>"; 
			
			$a=2;
			$b=4;
			$c=6;
			$d=2;
			$soma = $a + $c;
			$multip = $b*$d;
			
			if($soma > $multip)
			{
				echo "A+C é maior que B+D";
			}
			else if ($soma < $multip)
			{
				echo "A+C é menor que B+D";
			}
			else 
			{
				echo "A+C é igual que B+D";
			}
			
			//echo "$soma"."<br>";
			//echo "$multip";
			*/
			
			//function retornarDiaria()
			//{
				//return 900/30;
			//}
			//echo retornarDiaria();
			
			
	//		function retornarDiaria($salario, $dias, $cotacao)
		//	{
		//		$real = number_format($salario/$dias,2);
		//		$dolar = number_format(($salario/$dias)/($cotacao),2);
		//		return array($real, $dolar);
		//	}
			//$diaria_array = retornarDiaria(3000, 10, 2.5);
			
			//echo "Diária em R$" . $diaria_array[0] . "<br>";
		//	echo "Diária em U$" . $diaria_array[1] . "<br>";
			
			//$a = array ('a' => "apple", 'b' => "banana", 'c'=> array('x', 'y', 'z'));
			//print_r($a);
			
			
			
			//?> 	
			
			<label>
			<a> Receber 4 notas, calcule a média e se for acima de 75, exibir aprovado! </a>
			</label>
			
			<form name="exe1" action="enviar.php" method ="get">
			
			<label>
			<a> Nota 1 </a>
			</label>
			<input name="num" type="text">
			<br>
			
			<label>
			<a> Nota 2 </a>
			</label>
			<input name="num2" type="text">
			<br>
			
			<label>
			<a> Nota 3 </a>
			</label>
			<input name="num3" type="text">
			<br>
			
			<label>
			<a> Nota 4 </a>
			</label>
			<input name="num4" type="text">
			<br><br>
		    
			<input type="submit" name="text">	
			</form>
		</p>
		
		
		
		</center>
		
	</body>

</html>