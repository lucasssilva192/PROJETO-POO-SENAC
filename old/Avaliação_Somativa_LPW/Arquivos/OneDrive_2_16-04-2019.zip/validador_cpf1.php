<html>
	<head>
		<body>
		<?php 
			
            
            $cpf = $_POST['cpf'];
            $cpf2 = substr($cpf,0,9);
            
            $indice = 0;
            $i = 10;
            $soma = 0;
            $result = 0;
            $primeiro_digito = 0;
            $cpf_com_primeiro_digito = 0;
            
            //primeiro digito
            for ($i = 10; $i>1;$i--)
                {
                    // cada vez q o loop roda, o i diminui 1 e multiplica por cada item respectivo do cpf 
                    $soma = $soma + ($i*substr($cpf2, $indice++, 1));
                }
            
            //pega o resto com % ao inves do quociente
            $result = $soma % 11;
            
            if ($result<2)
                {
                    $primeiro_digito = 0;
                }
            else
                {
                    $primeiro_digito = 11-$result;
                }
            
            //segundo digito 
            
            $cpf2 = $cpf2.$primeiro_digito;
            
            //criar novas variaveis p n dar erro com as outras
            $soma2 = 0;
            $indice2 = 0;
            $i2 = 11;
            $result2 = 0;
            $segundo_digito= 0;
            
             for ($i2 = 11; $i2>1;$i2--)
                {
                    // cada vez q o loop roda, o i diminui 1 e multiplica por cada item respectivo do cpf 
                    $soma2 = $soma2 + ($i2*substr($cpf2, $indice2++, 1));
                }
            
            $result2 = $soma2 % 11;
            
            if($result2<2)
                {
                    $segundo_digito = 0;
                }
            else
                {
                    $segundo_digito = 11-$result2;
                }
            $cpf2= $cpf2.$segundo_digito;
        
            if($cpf == $cpf2)
            {
                echo "CPF Válido";
            }
            else
            {
                echo "CPF Inválido";
            }
             
		?>
		</body>
    </head>
</html>
