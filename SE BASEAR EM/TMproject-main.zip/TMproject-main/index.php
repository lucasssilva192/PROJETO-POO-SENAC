<?php

header('Location: views/index.php');

exit;

?>