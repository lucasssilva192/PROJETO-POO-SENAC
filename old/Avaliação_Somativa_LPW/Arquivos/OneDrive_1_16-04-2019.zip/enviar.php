<html>

	<head>

		<body>
		<?php 
			$num = $_GET['num'];
			
			$num2 = $_GET['num2'];
			
			$num3 = $_GET['num3'];
			
            $numeros = array($num, $num2,$num3);
            
            sort($numeros);
            
			echo . "<br>" . "Números crescentes:"
            $indice = 0;
            
            while ($indice<3)
            {
                echo $numeros[$indice] . "<br>";
            }
		?>
		</body>

	</head>

</html>