<footer class='bg-dark p-3 text-center bottom-0'>
  <div>
    <p class='text-muted mt-3'>Desenvolvido por Gabriel Sato ©<p>
  </div>
</footer>