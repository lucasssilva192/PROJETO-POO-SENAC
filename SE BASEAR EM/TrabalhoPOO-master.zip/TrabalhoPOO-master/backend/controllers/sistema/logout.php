<?php

(__DIR__);
include_once "./../../classes/loginClass.php";
$login = new Login();

$login->logout();