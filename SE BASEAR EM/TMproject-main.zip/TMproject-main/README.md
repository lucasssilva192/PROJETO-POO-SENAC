# TMproject
Projeto criado para a disciplina de POO do 3° semestre de TSI, com o intuito de aplicar os conhecimentos adquiridos. A ideia é criar um gerenciador de críticas sobre gostos pessoais.
